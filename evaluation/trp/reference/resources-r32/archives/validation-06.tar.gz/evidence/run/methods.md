# Métodos de la ejecución registrada

Se procesó 2xqh, cadena autora A, modelo 1, con 12 unidades suministradas. La entrada se identifica mediante SHA-256 90a558b1de03a9f329db99f6e1c0ec1ca2e3ac5d88c174537ca09b3603671f2a.

El adaptador trp-nextflow/1.3.0 generó la orden ["nextflow","-C","nextflow.config","run","main.nf","-ansi-log","false","-with-trace","trace.tsv"] y fijó la imagen sha256:1dd91e70acb153a0bd9a51346fc001dd5025f851c9598697cdd37f07d9490b0a. La revisión de GeomeTRe es 8bb0c50bb0bf73c16cc22e7bd4e3991a326841c9; su contrato de parámetros es ["chain","units","insertions (optional)","window=6 (upstream default; no CLI override)"]. Se planificaron dos tareas simuladas y dos reales, sin reintentos ni llamadas científicas remotas. Estado registrado: succeeded.

Salida observada de la consulta de versión de Nextflow: "\n      N E X T F L O W\n      version 25.10.4 build 11173\n      created 10-02-2026 15:17 UTC (10:17 PEST)\n      cite doi:10.1038/nbt.3820\n      http://nextflow.io\n\n".

La reserva estimada de almacenamiento fue 41771008 bytes. Los campos y sus fuentes se encuentran en methods.json; el inventario, el presupuesto, las decisiones y los eventos se conservan en archivos separados.

- Author-PDB numbering; supplied units, not repeat detection; experimental B-factor is not pLDDT.
- The first-unit geometry zeros are placeholders. External annotator, held-out evaluation and cluster are pending.
- Operator XFS quota and cgroup v2 bound controller and task resources. CPU quota is bandwidth, not exclusive cores. Full-run peaks are preserved by the external supervisor.
- Offline verification checks bytes and declared links, not scientific truth or an authenticated human identity.
- Agent provider/model/cost are not observed by this workflow; task software is identified by the pinned catalogue reference and image.
